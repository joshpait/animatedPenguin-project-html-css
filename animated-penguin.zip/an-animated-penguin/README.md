# An Animated Penguin

A Pen created on CodePen.io. Original URL: [https://codepen.io/Joshua-Pait/pen/xxQxvdR](https://codepen.io/Joshua-Pait/pen/xxQxvdR).

